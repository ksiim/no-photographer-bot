# Aiogram3.x Bot Template



change bot token in config.py and paste in terminal one command:
pip install -f requirements.txt